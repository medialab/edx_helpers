component: html
name: Echec de la politique

#Titre en Markdown
**test** de mot en gras
ok

![captions:left](/static/captions.png)
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sed blandit eros. Proin in elit lectus. Donec at felis urna. Cras gravida nunc mi, vel ultricies lectus mollis vel. Mauris ut magna mattis, semper tellus ac, sollicitudin lacus. Nam erat ante, facilisis id consequat quis, imperdiet a tellus. Quisque mauris turpis, pharetra eget nisl eu, luctus eleifend nisi. In volutpat orci vitae enim imperdiet dignissim. Aliquam ut odio pretium, euismod lectus ac, condimentum nisl. Sed mollis urna ut elit pretium lobortis. Morbi eu ante ligula. Ut mi tortor, ullamcorper sed blandit semper, pulvinar sit amet tellus.

Nam eu metus porttitor, dapibus turpis non, euismod odio. Donec ac tempor risus, at dictum est. Ut molestie orci vitae consequat euismod. Nulla in feugiat orci. Mauris sodales tincidunt vulputate. Donec malesuada non nibh eget iaculis. Fusce eget venenatis ante. Cras faucibus laoreet libero quis ullamcorper. Fusce ullamcorper libero est, non bibendum tellus commodo sit amet.

Sed porta nec risus eu consectetur. In ullamcorper, tortor non accumsan condimentum, nunc quam vulputate mi, eleifend ultrices tortor mauris sed nisi. Cras in tincidunt turpis, vel rhoncus ligula. Phasellus laoreet leo ac ante aliquet, sed viverra lorem scelerisque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Proin eget est at eros viverra facilisis at quis lorem. Maecenas volutpat elit nibh, ut tincidunt erat eleifend at. Nullam quis laoreet neque. Praesent convallis quam purus, non fringilla ipsum dictum sed. Duis elementum sapien vel dolor varius, ac lobortis tellus pellentesque. Nulla eget justo auctor, egestas nisi eget, blandit est.

##Titre de niveau 2

* * *

component: video
id: KL_v-y0AneEgit stat
name: Test Video

* * *

component: html
name: Bleu de bleu

#Fous du gaag
fafa *italic*

[Want to know what is there?](http://google.com)


* * *
component: html
name: Essayons un truc

#Titre 1
*italic*