component: html
name: Echec de la politique

#Titre en Markdown
**test** de mot en gras
ok

##Titre de niveau 2

* * *
component: video
id: KL_v-y0AneE
name: Test Video

* * *
component: html
name: Bleu de bleu

#Fous du gaag
fafa *italic*